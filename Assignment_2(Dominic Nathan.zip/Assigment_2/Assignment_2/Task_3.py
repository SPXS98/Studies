'''
Created on 23/09/2020

@author: Dominic Nathan
Pledge of Honor: I Dominic Nathan pledge by honor that this program is solely my own work.

Description of program: This program uses multiple functions to draw a podium with three different places 
and three different stick figures.
'''
from turtle import *

def move_to(x,y):
    pu()
    goto(x,y)
    pd()
    
def draw_head(x,y,radius):
    move_to(x, y)
    seth(0)
    circle(radius)
    
def draw_line(x1,y1,x2,y2):
    pu()
    goto(x1, y1)
    pd()
    goto(x2, y2)
    pu
    
def draw_block(x,y,height,width,colour):# Used to draw squares and rectangle
    move_to(x, y)
    seth(0)
    begin_fill()
    fillcolor(colour)
    for i in range(2):
        fd(width)
        left(90)
        fd(height)
        left(90)
    end_fill()
    
def draw_triangle_1(x, y, size, colour):# used to draw the second place triangle
    move_to(x, y)
    seth(0)
    begin_fill()
    fillcolor(colour)
    for i in range (3):
        fd(size)
        left(120)
    end_fill()
    
def draw_triangle_2(x, y, size, colour):# Used to draw the third place triangle
    move_to(x, y)
    seth(0)
    begin_fill()
    fillcolor(colour)
    for i in range (3):
        fd(size)
        right(120)
    end_fill()
    
def draw_podium(winner_colour,second_colour,third_colour):
    x,y,height,width = 0,0,60,60
    draw_block(x, y, height, width, second_colour)
    x,y,height,width = 60,0,90,60
    draw_block(x, y, height, width, winner_colour)
    x,y,height,width = 120,0,40,60
    draw_block(x, y, height, width, third_colour)
    

def draw_winner(colour):
    x,y,radius = 90, 160, 10
    draw_head(x, y, radius)# draws the head
    x1,y1,x2,y2 = 60, 180, 90, 140
    draw_line(x1, y1, x2, y2)# draws the left arm
    x1,y1,x2,y2 = 90,140, 120, 180
    draw_line(x1, y1, x2, y2)#draws the right arm
    x,y,height,width = 70, 120, 40, 40
    draw_block(x, y, height, width, colour)# draws the body
    x1,y1,x2,y2 = 80, 120, 80, 90
    draw_line(x1, y1, x2, y2)# left leg
    x1,y1,x2,y2 = 100, 120, 100, 90
    draw_line(x1, y1, x2, y2)# right leg
    
    
def draw_second(colour):
    x,y,radius = 30, 125, 10
    draw_head(x, y, radius)# draws the head
    x1,y1,x2,y2 = 0, 130, 30, 110
    draw_line(x1, y1, x2, y2)# draws the left arm
    x1,y1,x2,y2 = 30,110, 60, 130
    draw_line(x1, y1, x2, y2)#draws the right arm
    x,y,size = 10, 90, 40
    draw_triangle_1(x, y, size, colour)
    x1,y1,x2,y2 = 20, 90, 20, 60
    draw_line(x1, y1, x2, y2)# left leg
    x1,y1,x2,y2 = 40, 90, 40, 60
    draw_line(x1, y1, x2, y2)# right leg
    

def draw_third(colour):
    x,y,radius = 150, 90, 10
    draw_head(x, y, radius)# draws the head
    x1,y1,x2,y2 = 120, 120, 150, 70
    draw_line(x1, y1, x2, y2)# draws the left arm
    x1,y1,x2,y2 = 150, 70, 180, 120
    draw_line(x1, y1, x2, y2)#draws the right arm
    x,y,size = 130, 90, 40
    draw_triangle_2(x, y, size, colour)
    x1,y1,x2,y2 = 140, 70, 140, 40
    draw_line(x1, y1, x2, y2)# left leg
    x1,y1,x2,y2 = 160, 70, 160, 40
    draw_line(x1, y1, x2, y2)# right leg
    
    
def main():
    winner_colour,second_colour,third_colour = "red", "orange", "purple"
    draw_podium(winner_colour, second_colour, third_colour)
    draw_winner(winner_colour)
    draw_second(second_colour)
    draw_third(third_colour)
    exitonclick()
main()