'''
Created on 23/09/2020

@author: Dominic Nathan

Pledge of Honor: I Dominic Nathan pledge by honor that this program is solely my own work.

Description of program: This program asks the user for to input the number of cameras installed and then asks how many incidents there were per camera,
the program then displays the number of cameras and the number of incidents in a list with a title above them, it then calculates the average number of 
incidents and outputs it

'''
while True:# Loop to make sure the user inputs the correct data if not it prompts a message
    cam_qty = int(input("How many speed cameras are installed (1 - 150): "))
    if cam_qty >= 1 and cam_qty <= 150:
        break
    else:
        print("Invalid. Must be between 1-150.")

cam_num = 0
incident_list = []

while cam_qty > cam_num:
    cam_num += 1
    incident_list.append(int(input(f"Enter number of incident with camera {cam_num}: ")))

fmt = "{:^15}{:^17}"

print("Display incident list:")
print(fmt.format("Camera Number.", "Number of incidents"))
print("-"*13, "-"*20)
for index, incident_num in enumerate(incident_list, start = 1):
    print(fmt.format(index, incident_num))
    
avg = sum(incident_list) / len(incident_list)

print(f"Average number of incidents: {avg:.2f}")
    
