'''
Created on 23/09/2020

@author: Dominic Nathan
Pledge of Honor: I Dominic Nathan pledge by honor that this program is solely my own work.

Description of program: This program reads file data and displays that data statistically by using many different functions.

Created on 5/10/2020

@author: Dominic Nathan
'''
from datetime import datetime
def read_data(filename):# Reads the external data sheet
    records = []
    with open(filename) as readfile:
        for line in readfile:
            line = line.strip()
            str_rec = line.split(",")
            dobj = datetime.strptime(str_rec[6],"%d-%m-%Y")
            rec = [str_rec[0], str_rec[1], int(str_rec[2]), float(str_rec[3]),int(str_rec[4]),str_rec[5], dobj]
            records.append(rec)
            
    return records

def write_data(filename,records):# Creates a backup data sheet
    with open(filename, "w") as writefile:
        for rec in records:
            dstr = f"{rec[6]:%d-%m-%Y}"
            str_rec = [dstr, rec[0], str(rec[1]), str(rec[2]), str(rec[3]), str(rec[4]), str(rec[5]), str(rec[6])]
            line = ",".join(str_rec)
            writefile.write(line + "\n")

        
        
def print_all_records(records):# prints all records and formats them accordingly
    h1, h2, h3, h4, h5, h6, h7 = "Name", "Industry", "Revenue", "Revenue growth ", "Employees", "Headerquater", "Founded"
    print(f"{h1:20}{h2:25}{h3:20}{h4:20}{h5:20}{h6:20}{h7}")
    print("-" * 80)
    for rec in records:
        dstr = f"{rec[6]:%d-%m-%Y}"
        print(f"{rec[0]:20}{rec[1]:25}{rec[2]:<20}{rec[3]:<20}{rec[4]:<20}{rec[5]:20}{dstr}")
        

def print_positive_growth(records): #prints the growth of each Business
    h1, h2, h3, h4, h5, h6, h7 = "Name", "Industry", "Revenue", "Revenue growth ", "Employees", "Headerquater", "Founded"
    print(f"{h1:20}{h2:25}{h3:20}{h4:20}{h5:20}{h6:20}{h7}")
    print("-" * 80)
    for rec in records: 
        if rec [3] > 0:
                print(f"{rec[0]:20}{rec[1]:25}{rec[2]:<20}{rec[3]:<20}{rec[4]:<20}{rec[5]:20}{rec[6]: %d/%m/%Y}")
             

def query_record_by_date(records):# Ask user to input date and then displays the data
    dstr = input ("Enter a date (dd mm yyyy): ")
    dobj = datetime.strptime(dstr, "%d %m %Y")
    rec_found = None 
    for rec in records:# Uses user input checking to make sure the data the user is enter is correct
        if rec[6] == dobj:
            rec_found = rec
            print(f"Company Name: {rec[0]} Revenue: {rec[2]}")
            
    
    if rec_found == None:
        print(f"No record for {dstr}")
          
    
def query_total_revenue_by_industry(records):# Displays the total and average of each industries revenue
    name = input("Please enter an indusrty: ")
    avg = 0
    total = 0
    count = 0
    for rec in records:
        if name.lower() == rec[1].lower():
            total += rec[2]
            count += 1  
    if count >0:
            print(f"Total Revenue (USD Billion): {total:.2f}")
            print(f"Average Revenue (USD Billion): {total/count:.2f}")
        
    if count == 0:
        print(f"No search results for: {name}")
        
        

def count_companies_between_dates(records):# This function ask the user for two dates and display the companies founded between those dates
    
    dstr_start = input("Please enter a start date (dd/mm/yyyy): ") 
    dstr_end = input("Please enter a end date (dd/mm/yyyy): ")
    dobj_start = datetime.strptime(dstr_start, "%d/%m/%Y")
    dobj_end = datetime.strptime(dstr_end, "%d/%m/%Y")
    
    total= 0
    for rec in records:
        if rec[6] >= dobj_start and rec[6] <= dobj_end:
            total += 1
            
    
    print(f"The number of companies founded between  {dstr_start} - {dstr_end}: {total}")
    
        
def main():
    data = read_data("data.txt")
    print_all_records(data)
    query_record_by_date(data)
    print_positive_growth(data)
    query_total_revenue_by_industry(data)
    count_companies_between_dates(data)
    write_data("backup.txt", data)
    
main()