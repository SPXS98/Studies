'''
Created on 23/09/2020

@author: Dominic Nathan
Pledge of Honor: I Dominic Nathan pledge by honor that this program is solely my own work.

Description of program: This program acts as a preset database and allows users to access course details
as well as student pass rate and averages for those courses, the program also checks the users input for
user input checking.
'''
def get_data():#List with stored data 
    course_list = []
    course_list.append(["comp001", "Fundamentals", 96, 84])
    course_list.append(["comp002", "Database Principles", 104, 92])
    course_list.append(["comp003", "Networking", 120, 106])
    course_list.append(["comp004", "Website Development", 110, 102])
    return course_list

def print_course_list(records):# Prints all of the data and format the data as specified
    h1, h2, h3,h4 = "Course ID", "Course Name", "Num Students", "Num Passed"
    print(f"{h1:20}{h2:25}{h3:20}{h4:20}")
    row = 1
    for rec in records:
        print(f"{rec[0]:<20}{rec[1]:<25}{rec[2]:<20}{rec[3]:<20}")
        row =+ 1


    
    
def overall_summary(records):
        total = 0
        total2 = 0
        for rec in records:
            total += rec[2]#rec[2] retrieves the score of each record
            total2 += rec[3]#rec[3] retrieves the score of each record
        print(f"Total students: {total}")
        print(f"Total students passed: {total2}")
        print(f"Average pass rate: {total2/total*100:.2f}%")
            
    
    
def course_summary(records): # loop used for user input error 
    name = input("Enter a course ID: ")
    rec_found = None 
    for rec in records:
        if name.lower() == rec[0].lower():
            rec_found = rec 
            break

    if rec_found == None:
      print(f"No records found for:{name}")
    else:
        print(f"Course name: {rec_found[1]}")
        print(f"Total Students: {rec_found[2]}")
        print(f"Students passing {rec_found[0]}: {rec_found[3]}")
        print(f"Students passing {rec_found[0]}: {rec_found[3]/rec_found[2]*100:.2f}%")

    


def main():
    data = get_data()
    print_course_list(data)
    overall_summary(data)
    course_summary(data)
main()
    