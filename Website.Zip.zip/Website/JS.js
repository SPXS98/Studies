 

var stuNmae = "Dominic";
var num = "60";
var x =10;
var y =15;
var z = x + y;

document.getElementbyID("sum").innerHTML = "The answer is"+ z;
